<ul>
  <li>
    <a href="home.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>

  <li>
    <a href="add_sale.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Add shop Sale</span>
    </a>
    </li>

      <li>
    <a href="sales.php" class="submenu-toggle">
      <i class="" ="glyphicon glyphicon-user"></i>
      <span>Manage Shop Sale</span>
    </a>
    </li>

</ul>
