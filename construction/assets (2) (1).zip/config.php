<?php
/*
|--------------------------------------------------------------------------
| OWSA-INV V2
|--------------------------------------------------------------------------
| Author: Siamon Hasan
| Project Name: OSWA-INV
| Version: v2
| Offcial page: http://oswapp.com/
| facebook Page: https://www.facebook.com/oswapp
|
|
|
*/
  define( 'DB_HOST', 'localhost' );          // Set database host
  define( 'DB_USER', 'asteamso_soft' );             // Set database user
  define( 'DB_PASS', '5karachi5' );             // Set database password
  define( 'DB_NAME', 'asteamso_soft' );        // Set database name

?>
