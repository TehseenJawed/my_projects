<?php
/*
|--------------------------------------------------------------------------
| OWSA-INV V2
|--------------------------------------------------------------------------
| Author: Siamon Hasan
| Project Name: OSWA-INV
| Version: v2
| Offcial page: http://oswapp.com/
| facebook Page: https://www.facebook.com/oswapp
|
|
|
*/
  define( 'DB_HOST', '167.114.158.128' );          // Set database host
  define( 'DB_USER', 'ubbasoft_ubbasoft' );             // Set database user
  define( 'DB_PASS', '5pakistan5' );             // Set database password
  define( 'DB_NAME', 'ubbasoft_soft' );        // Set database name

?>
